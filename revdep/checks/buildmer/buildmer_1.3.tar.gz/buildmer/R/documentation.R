#' Construct and fit as complete a model as possible and perform stepwise elimination
#' 
#' The \code{buildmer} package consists of a number of functions, each designed to fit specific types of models (e.g. \code{\link{buildmer}} for mixed-effects regression, \code{\link{buildgam}} for generalized additive models, \code{\link{buildmertree}} for mixed-effects-regression trees, and so forth. The common parameters shared by all (or most of) these functions are documented here. If you are looking for a more general description of what the various \code{build...} functions do, see under `Details'. For function-specific details, see the documentation for each individual function.
#' 
#' With the default options, all \code{buildmer} functions will do two things:
#' \enumerate{
#' \item Determine the order of the effects in your model, based on their importance as measured by the likelihood-ratio test statistic. This identifies the `maximal model', which is the model containing either all effects specified by the user, or subset of those effects that still allow the model to converge, ordered such that the most information-rich effects have made it in.
#' \item Perform backward stepwise elimination based on the significance of the change in log-likelihood.
#' }
#' The final model is returned in the \code{model} slot of the returned \code{buildmer} object.
#' All functions in the \code{buildmer} package are aware of the distinction between (f)REML and ML, and know to divide chi-square \emph{p}-values by 2 when comparing models differing only in random effects (see Pinheiro & Bates 2000).
#' The steps executed above can be changed using the \code{direction} argument, allowing for arbitrary chains of, for instance, forward-backward-forward stepwise elimination (although using more than one elimination method on the same data is not recommended). The criterion for determining the importance of terms in the ordering stage and the elimination of terms in the elimination stage can also be changed, using the \code{crit} argument.
#' 
#' @param formula The model formula for the maximal model you would like to fit. Alternatively, a buildmer term list as obtained from \code{\link{tabulate.formula}}. In the latter formulation, you also need to specify a \code{dep='...'} argument specifying the dependent variable to go along with the term list. See \code{\link{tabulate.formula}} for an example of where this is useful
#' @param data The data to fit the model(s) to
#' @param family The error distribution to use
#' @param cl An optional cluster object as returned by function \code{makeCluster} from package \code{parallel} to use for parallelizing the evaluation of terms. Note that, if and only if using the \code{cl} functionality, the data and other arguments will be searched for in the global environment only, so you should manually set up the cluster's environments using \code{clusterExport()} if necessary. In addition, some buildmer-internal objects will be exported to the cluster nodes. These will be cleaned up afterwards, but any already-present objects with the same name (e.g. `\code{p}' will be overwritten)
#' @param direction Character string or vector indicating the direction for stepwise elimination; possible options are \code{'order'} (order terms by their contribution to the model), \code{'backward'} (backward elimination), \code{'forward'} (forward elimination, implies \code{order}). The default is the combination \code{c('order','backward')}, to first make sure that the model converges and to then perform backward elimination; other such combinations are perfectly allowed
#' @param crit Character string or vector determining the criterion used to test terms for elimination. Possible options are \code{'LRT'} (likelihood-ratio test; this is the default), \code{'LL'} (use the raw -2 log likelihood), \code{'AIC'} (Akaike Information Criterion), and \code{'BIC'} (Bayesian Information Criterion)
#' @param include A one-sided formula or character vector of terms that will be kept in the model at all times. These do not need to be specified separately in the \code{formula} argument. Useful for e.g. passing correlation structures in \code{glmmTMB} models
#' @param reduce.fixed Logical indicating whether to reduce the fixed-effect structure
#' @param reduce.random Logical indicating whether to reduce the random-effect structure
#' @param calc.anova Logical indicating whether to also calculate the ANOVA table for the final model after term elimination
#' @param calc.summary Logical indicating whether to also calculate the summary table for the final model after term elimination
#' @examples
#' \donttest{
#' # Only finding the maximal model, with importance of effects measured by AIC, parallelizing the
#' # model evaluations using two cores, using the bobyqa optimizer and asking for verbose output
#' library(parallel)
#' cl <- makeCluster(2,outfile='')
#' control <- lme4::lmerControl(optimizer='bobyqa')
#' clusterExport(cl,'control') #this is not done automatically for '...' arguments!
#' m <- buildmer(f1 ~ vowel*timepoint*following + (vowel*timepoint*following|participant) +
#'               (timepoint|word),data=vowels,cl=cl,direction='order',crit='AIC',calc.anova=FALSE,
#'               calc.summary=FALSE,control=control,verbose=2)
#' # The maximal model is: f1 ~ vowel + timepoint + vowel:timepoint + following +
#' # timepoint:following +vowel:following + vowel:timepoint:following + (1 + timepoint +
#' # following + timepoint:following | participant) + (1 + timepoint | word)
#' # Now do backward stepwise elimination (result: f1 ~ vowel + timepoint + vowel:timepoint +
#' # following + timepoint:following + (1 + timepoint + following + timepoint:following |
#' # participant) + (1 + timepoint | word))
#' buildmer(formula(m@model),data=vowels,direction='backward',crit='AIC',control=control)
#' # Or forward (result: retains the full model)
#' buildmer(formula(m@model),data=vowels,direction='forward',crit='AIC',control=control)
#' # Print summary with p-values based on Satterthwaite denominator degrees of freedom
#' summary(m,ddf='Satterthwaite')
#' 
#' # Example for fitting a model without correlations in the random part
#' # (even for factor variables!)
#' # 1. Create explicit columns for factor variables
#' library(buildmer)
#' vowels <- cbind(vowels,model.matrix(~vowel,vowels))
#' # 2. Create formula with diagonal covariance structure
#' form <- diag(f1 ~ (vowel1+vowel2+vowel3+vowel4)*timepoint*following + 
#' 	     ((vowel1+vowel2+vowel3+vowel4)*timepoint*following | participant) +
#' 	     (timepoint | word))
#' # 3. Convert formula to buildmer terms list, grouping terms starting with 'vowel'
#' terms <- tabulate.formula(form,group='vowel[^:]')
#' # 4. Directly pass the terms object to buildmer(), using the hidden 'dep' argument to specify
#' # the dependent variable
#' m <- buildmer(terms,data=vowels,dep='f1')
#' }
#' @docType package
#' @name buildmer-package
NULL

#' A very small data set from a pilot study on sound change.
#' @docType data
#' @usage data(migrant)
#' @format A standard data frame.
'migrant'

#' Vowel data from a pilot study.
#' @docType data
#' @usage data(vowels)
#' @format A standard data frame.
'vowels'
