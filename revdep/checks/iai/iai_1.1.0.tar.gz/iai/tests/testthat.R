library(testthat)
library(iai)

test_check("iai")
