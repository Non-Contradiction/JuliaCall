# iai 1.1.0

* Add API for Optimal Feature Selection and advanced tree visualization
* Display visualizations in the viewer if available
* Update titles of documentation pages
* No longer need to run `iai_setup()` before using `iai` functions

# iai 1.0.0

* Initial release
