library(testthat)
library(convexjlr)

test_check("convexjlr")
