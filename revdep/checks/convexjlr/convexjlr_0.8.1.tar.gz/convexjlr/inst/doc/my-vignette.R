## ---- results='asis', echo=FALSE-----------------------------------------
cat(paste(readLines("original-vignette.md"), collapse = "\n"))

